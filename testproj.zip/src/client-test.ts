
import { CheqdSDK,ICheqdSDKOptions } from '@cheqd/sdk'
import { DIDModule } from '@cheqd/sdk'
import { AbstractCheqdSDKModule } from '@cheqd/sdk'
import { 
	DirectSecp256k1HdWallet
} from '@cosmjs/proto-signing'


const generateOptions = async (): Promise<ICheqdSDKOptions> => {
    const wallet: DirectSecp256k1HdWallet = await DirectSecp256k1HdWallet.generate(24)
    process.stdout.write(wallet.mnemonic)
    const modules = [DIDModule as unknown as AbstractCheqdSDKModule]
    const rpcUrl = "http://127.0.0.1:26657"
    const options: ICheqdSDKOptions = {
        modules: modules,
        rpcUrl: rpcUrl,
        wallet: wallet
    }
    return options
}




const yo = async (): Promise<void> => {
    const option = await generateOptions()
    const cheqdSdk = new CheqdSDK(option)
    console.log("yoooo")
    const doc: any = {
        id: "did:cosmos:net:cash:Alice",
        controller: "did:cosmos:net:cash:Alice"
    }
    const accounts = await option.wallet.getAccounts()
    const address = accounts[0].address
   const response = await cheqdSdk.createDidDocTx(doc,address)
    console.log("check")

}


yo()