---
description: >-
  This is the NOTICE file as described under the Apache License 2.0 terms for inclusion in downstream software projects that use this code.
---

# Notice

Copyright 2021-2022 Cheqd Foundation Limited

This product includes software developed at Cheqd Foundation Limited, doing business as "cheqd"
