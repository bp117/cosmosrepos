/* eslint-disable */
export const protobufPackage = "google.api";
//# sourceMappingURL=annotations.js.map