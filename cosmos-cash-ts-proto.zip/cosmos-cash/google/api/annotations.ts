/* eslint-disable */

export const protobufPackage = "google.api";
