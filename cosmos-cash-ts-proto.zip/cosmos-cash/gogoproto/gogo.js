/* eslint-disable */
export const protobufPackage = "gogoproto";
//# sourceMappingURL=gogo.js.map