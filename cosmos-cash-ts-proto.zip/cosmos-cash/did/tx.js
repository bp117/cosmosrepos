/* eslint-disable */
import Long from "long";
import _m0 from "protobufjs/minimal";
import { DidDocument, Service, VerificationMethod } from "./did";
export const protobufPackage = "allinbits.cosmoscash.did";
function createBaseVerification() {
    return { relationships: [], method: undefined, context: [] };
}
export const Verification = {
    encode(message, writer = _m0.Writer.create()) {
        for (const v of message.relationships) {
            writer.uint32(10).string(v);
        }
        if (message.method !== undefined) {
            VerificationMethod.encode(message.method, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.context) {
            writer.uint32(26).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseVerification();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.relationships.push(reader.string());
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.method = VerificationMethod.decode(reader, reader.uint32());
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.context.push(reader.string());
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            relationships: Array.isArray(object?.relationships) ? object.relationships.map((e) => String(e)) : [],
            method: isSet(object.method) ? VerificationMethod.fromJSON(object.method) : undefined,
            context: Array.isArray(object?.context) ? object.context.map((e) => String(e)) : [],
        };
    },
    toJSON(message) {
        const obj = {};
        if (message.relationships) {
            obj.relationships = message.relationships.map((e) => e);
        }
        else {
            obj.relationships = [];
        }
        message.method !== undefined &&
            (obj.method = message.method ? VerificationMethod.toJSON(message.method) : undefined);
        if (message.context) {
            obj.context = message.context.map((e) => e);
        }
        else {
            obj.context = [];
        }
        return obj;
    },
    create(base) {
        return Verification.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseVerification();
        message.relationships = object.relationships?.map((e) => e) || [];
        message.method = (object.method !== undefined && object.method !== null)
            ? VerificationMethod.fromPartial(object.method)
            : undefined;
        message.context = object.context?.map((e) => e) || [];
        return message;
    },
};
function createBaseMsgCreateDidDocument() {
    return { id: "", controllers: [], verifications: [], services: [], signer: "" };
}
export const MsgCreateDidDocument = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        for (const v of message.controllers) {
            writer.uint32(18).string(v);
        }
        for (const v of message.verifications) {
            Verification.encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.services) {
            Service.encode(v, writer.uint32(34).fork()).ldelim();
        }
        if (message.signer !== "") {
            writer.uint32(42).string(message.signer);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgCreateDidDocument();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.controllers.push(reader.string());
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.verifications.push(Verification.decode(reader, reader.uint32()));
                    continue;
                case 4:
                    if (tag != 34) {
                        break;
                    }
                    message.services.push(Service.decode(reader, reader.uint32()));
                    continue;
                case 5:
                    if (tag != 42) {
                        break;
                    }
                    message.signer = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            id: isSet(object.id) ? String(object.id) : "",
            controllers: Array.isArray(object?.controllers) ? object.controllers.map((e) => String(e)) : [],
            verifications: Array.isArray(object?.verifications)
                ? object.verifications.map((e) => Verification.fromJSON(e))
                : [],
            services: Array.isArray(object?.services) ? object.services.map((e) => Service.fromJSON(e)) : [],
            signer: isSet(object.signer) ? String(object.signer) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.id !== undefined && (obj.id = message.id);
        if (message.controllers) {
            obj.controllers = message.controllers.map((e) => e);
        }
        else {
            obj.controllers = [];
        }
        if (message.verifications) {
            obj.verifications = message.verifications.map((e) => e ? Verification.toJSON(e) : undefined);
        }
        else {
            obj.verifications = [];
        }
        if (message.services) {
            obj.services = message.services.map((e) => e ? Service.toJSON(e) : undefined);
        }
        else {
            obj.services = [];
        }
        message.signer !== undefined && (obj.signer = message.signer);
        return obj;
    },
    create(base) {
        return MsgCreateDidDocument.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseMsgCreateDidDocument();
        message.id = object.id ?? "";
        message.controllers = object.controllers?.map((e) => e) || [];
        message.verifications = object.verifications?.map((e) => Verification.fromPartial(e)) || [];
        message.services = object.services?.map((e) => Service.fromPartial(e)) || [];
        message.signer = object.signer ?? "";
        return message;
    },
};
function createBaseMsgCreateDidDocumentResponse() {
    return {};
}
export const MsgCreateDidDocumentResponse = {
    encode(_, writer = _m0.Writer.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgCreateDidDocumentResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(_) {
        return {};
    },
    toJSON(_) {
        const obj = {};
        return obj;
    },
    create(base) {
        return MsgCreateDidDocumentResponse.fromPartial(base ?? {});
    },
    fromPartial(_) {
        const message = createBaseMsgCreateDidDocumentResponse();
        return message;
    },
};
function createBaseMsgUpdateDidDocument() {
    return { doc: undefined, signer: "" };
}
export const MsgUpdateDidDocument = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.doc !== undefined) {
            DidDocument.encode(message.doc, writer.uint32(10).fork()).ldelim();
        }
        if (message.signer !== "") {
            writer.uint32(42).string(message.signer);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateDidDocument();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.doc = DidDocument.decode(reader, reader.uint32());
                    continue;
                case 5:
                    if (tag != 42) {
                        break;
                    }
                    message.signer = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            doc: isSet(object.doc) ? DidDocument.fromJSON(object.doc) : undefined,
            signer: isSet(object.signer) ? String(object.signer) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.doc !== undefined && (obj.doc = message.doc ? DidDocument.toJSON(message.doc) : undefined);
        message.signer !== undefined && (obj.signer = message.signer);
        return obj;
    },
    create(base) {
        return MsgUpdateDidDocument.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseMsgUpdateDidDocument();
        message.doc = (object.doc !== undefined && object.doc !== null) ? DidDocument.fromPartial(object.doc) : undefined;
        message.signer = object.signer ?? "";
        return message;
    },
};
function createBaseMsgUpdateDidDocumentResponse() {
    return {};
}
export const MsgUpdateDidDocumentResponse = {
    encode(_, writer = _m0.Writer.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateDidDocumentResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(_) {
        return {};
    },
    toJSON(_) {
        const obj = {};
        return obj;
    },
    create(base) {
        return MsgUpdateDidDocumentResponse.fromPartial(base ?? {});
    },
    fromPartial(_) {
        const message = createBaseMsgUpdateDidDocumentResponse();
        return message;
    },
};
function createBaseMsgAddVerification() {
    return { id: "", verification: undefined, signer: "" };
}
export const MsgAddVerification = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.verification !== undefined) {
            Verification.encode(message.verification, writer.uint32(18).fork()).ldelim();
        }
        if (message.signer !== "") {
            writer.uint32(26).string(message.signer);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgAddVerification();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.verification = Verification.decode(reader, reader.uint32());
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.signer = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            id: isSet(object.id) ? String(object.id) : "",
            verification: isSet(object.verification) ? Verification.fromJSON(object.verification) : undefined,
            signer: isSet(object.signer) ? String(object.signer) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.id !== undefined && (obj.id = message.id);
        message.verification !== undefined &&
            (obj.verification = message.verification ? Verification.toJSON(message.verification) : undefined);
        message.signer !== undefined && (obj.signer = message.signer);
        return obj;
    },
    create(base) {
        return MsgAddVerification.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseMsgAddVerification();
        message.id = object.id ?? "";
        message.verification = (object.verification !== undefined && object.verification !== null)
            ? Verification.fromPartial(object.verification)
            : undefined;
        message.signer = object.signer ?? "";
        return message;
    },
};
function createBaseMsgAddVerificationResponse() {
    return {};
}
export const MsgAddVerificationResponse = {
    encode(_, writer = _m0.Writer.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgAddVerificationResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(_) {
        return {};
    },
    toJSON(_) {
        const obj = {};
        return obj;
    },
    create(base) {
        return MsgAddVerificationResponse.fromPartial(base ?? {});
    },
    fromPartial(_) {
        const message = createBaseMsgAddVerificationResponse();
        return message;
    },
};
function createBaseMsgSetVerificationRelationships() {
    return { id: "", methodId: "", relationships: [], signer: "" };
}
export const MsgSetVerificationRelationships = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.methodId !== "") {
            writer.uint32(18).string(message.methodId);
        }
        for (const v of message.relationships) {
            writer.uint32(26).string(v);
        }
        if (message.signer !== "") {
            writer.uint32(34).string(message.signer);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSetVerificationRelationships();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.methodId = reader.string();
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.relationships.push(reader.string());
                    continue;
                case 4:
                    if (tag != 34) {
                        break;
                    }
                    message.signer = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            id: isSet(object.id) ? String(object.id) : "",
            methodId: isSet(object.methodId) ? String(object.methodId) : "",
            relationships: Array.isArray(object?.relationships) ? object.relationships.map((e) => String(e)) : [],
            signer: isSet(object.signer) ? String(object.signer) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.id !== undefined && (obj.id = message.id);
        message.methodId !== undefined && (obj.methodId = message.methodId);
        if (message.relationships) {
            obj.relationships = message.relationships.map((e) => e);
        }
        else {
            obj.relationships = [];
        }
        message.signer !== undefined && (obj.signer = message.signer);
        return obj;
    },
    create(base) {
        return MsgSetVerificationRelationships.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseMsgSetVerificationRelationships();
        message.id = object.id ?? "";
        message.methodId = object.methodId ?? "";
        message.relationships = object.relationships?.map((e) => e) || [];
        message.signer = object.signer ?? "";
        return message;
    },
};
function createBaseMsgSetVerificationRelationshipsResponse() {
    return {};
}
export const MsgSetVerificationRelationshipsResponse = {
    encode(_, writer = _m0.Writer.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSetVerificationRelationshipsResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(_) {
        return {};
    },
    toJSON(_) {
        const obj = {};
        return obj;
    },
    create(base) {
        return MsgSetVerificationRelationshipsResponse.fromPartial(base ?? {});
    },
    fromPartial(_) {
        const message = createBaseMsgSetVerificationRelationshipsResponse();
        return message;
    },
};
function createBaseMsgRevokeVerification() {
    return { id: "", methodId: "", signer: "" };
}
export const MsgRevokeVerification = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.methodId !== "") {
            writer.uint32(18).string(message.methodId);
        }
        if (message.signer !== "") {
            writer.uint32(26).string(message.signer);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgRevokeVerification();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.methodId = reader.string();
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.signer = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            id: isSet(object.id) ? String(object.id) : "",
            methodId: isSet(object.methodId) ? String(object.methodId) : "",
            signer: isSet(object.signer) ? String(object.signer) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.id !== undefined && (obj.id = message.id);
        message.methodId !== undefined && (obj.methodId = message.methodId);
        message.signer !== undefined && (obj.signer = message.signer);
        return obj;
    },
    create(base) {
        return MsgRevokeVerification.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseMsgRevokeVerification();
        message.id = object.id ?? "";
        message.methodId = object.methodId ?? "";
        message.signer = object.signer ?? "";
        return message;
    },
};
function createBaseMsgRevokeVerificationResponse() {
    return {};
}
export const MsgRevokeVerificationResponse = {
    encode(_, writer = _m0.Writer.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgRevokeVerificationResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(_) {
        return {};
    },
    toJSON(_) {
        const obj = {};
        return obj;
    },
    create(base) {
        return MsgRevokeVerificationResponse.fromPartial(base ?? {});
    },
    fromPartial(_) {
        const message = createBaseMsgRevokeVerificationResponse();
        return message;
    },
};
function createBaseMsgAddService() {
    return { id: "", serviceData: undefined, signer: "" };
}
export const MsgAddService = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.serviceData !== undefined) {
            Service.encode(message.serviceData, writer.uint32(18).fork()).ldelim();
        }
        if (message.signer !== "") {
            writer.uint32(26).string(message.signer);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgAddService();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.serviceData = Service.decode(reader, reader.uint32());
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.signer = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            id: isSet(object.id) ? String(object.id) : "",
            serviceData: isSet(object.serviceData) ? Service.fromJSON(object.serviceData) : undefined,
            signer: isSet(object.signer) ? String(object.signer) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.id !== undefined && (obj.id = message.id);
        message.serviceData !== undefined &&
            (obj.serviceData = message.serviceData ? Service.toJSON(message.serviceData) : undefined);
        message.signer !== undefined && (obj.signer = message.signer);
        return obj;
    },
    create(base) {
        return MsgAddService.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseMsgAddService();
        message.id = object.id ?? "";
        message.serviceData = (object.serviceData !== undefined && object.serviceData !== null)
            ? Service.fromPartial(object.serviceData)
            : undefined;
        message.signer = object.signer ?? "";
        return message;
    },
};
function createBaseMsgAddServiceResponse() {
    return {};
}
export const MsgAddServiceResponse = {
    encode(_, writer = _m0.Writer.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgAddServiceResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(_) {
        return {};
    },
    toJSON(_) {
        const obj = {};
        return obj;
    },
    create(base) {
        return MsgAddServiceResponse.fromPartial(base ?? {});
    },
    fromPartial(_) {
        const message = createBaseMsgAddServiceResponse();
        return message;
    },
};
function createBaseMsgDeleteService() {
    return { id: "", serviceId: "", signer: "" };
}
export const MsgDeleteService = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.serviceId !== "") {
            writer.uint32(18).string(message.serviceId);
        }
        if (message.signer !== "") {
            writer.uint32(26).string(message.signer);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgDeleteService();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.serviceId = reader.string();
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.signer = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            id: isSet(object.id) ? String(object.id) : "",
            serviceId: isSet(object.serviceId) ? String(object.serviceId) : "",
            signer: isSet(object.signer) ? String(object.signer) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.id !== undefined && (obj.id = message.id);
        message.serviceId !== undefined && (obj.serviceId = message.serviceId);
        message.signer !== undefined && (obj.signer = message.signer);
        return obj;
    },
    create(base) {
        return MsgDeleteService.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseMsgDeleteService();
        message.id = object.id ?? "";
        message.serviceId = object.serviceId ?? "";
        message.signer = object.signer ?? "";
        return message;
    },
};
function createBaseMsgDeleteServiceResponse() {
    return {};
}
export const MsgDeleteServiceResponse = {
    encode(_, writer = _m0.Writer.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgDeleteServiceResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(_) {
        return {};
    },
    toJSON(_) {
        const obj = {};
        return obj;
    },
    create(base) {
        return MsgDeleteServiceResponse.fromPartial(base ?? {});
    },
    fromPartial(_) {
        const message = createBaseMsgDeleteServiceResponse();
        return message;
    },
};
function createBaseMsgAddController() {
    return { id: "", controllerDid: "", signer: "" };
}
export const MsgAddController = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.controllerDid !== "") {
            writer.uint32(18).string(message.controllerDid);
        }
        if (message.signer !== "") {
            writer.uint32(26).string(message.signer);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgAddController();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.controllerDid = reader.string();
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.signer = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            id: isSet(object.id) ? String(object.id) : "",
            controllerDid: isSet(object.controllerDid) ? String(object.controllerDid) : "",
            signer: isSet(object.signer) ? String(object.signer) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.id !== undefined && (obj.id = message.id);
        message.controllerDid !== undefined && (obj.controllerDid = message.controllerDid);
        message.signer !== undefined && (obj.signer = message.signer);
        return obj;
    },
    create(base) {
        return MsgAddController.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseMsgAddController();
        message.id = object.id ?? "";
        message.controllerDid = object.controllerDid ?? "";
        message.signer = object.signer ?? "";
        return message;
    },
};
function createBaseMsgAddControllerResponse() {
    return {};
}
export const MsgAddControllerResponse = {
    encode(_, writer = _m0.Writer.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgAddControllerResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(_) {
        return {};
    },
    toJSON(_) {
        const obj = {};
        return obj;
    },
    create(base) {
        return MsgAddControllerResponse.fromPartial(base ?? {});
    },
    fromPartial(_) {
        const message = createBaseMsgAddControllerResponse();
        return message;
    },
};
function createBaseMsgDeleteController() {
    return { id: "", controllerDid: "", signer: "" };
}
export const MsgDeleteController = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.controllerDid !== "") {
            writer.uint32(18).string(message.controllerDid);
        }
        if (message.signer !== "") {
            writer.uint32(26).string(message.signer);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgDeleteController();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.controllerDid = reader.string();
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.signer = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            id: isSet(object.id) ? String(object.id) : "",
            controllerDid: isSet(object.controllerDid) ? String(object.controllerDid) : "",
            signer: isSet(object.signer) ? String(object.signer) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.id !== undefined && (obj.id = message.id);
        message.controllerDid !== undefined && (obj.controllerDid = message.controllerDid);
        message.signer !== undefined && (obj.signer = message.signer);
        return obj;
    },
    create(base) {
        return MsgDeleteController.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseMsgDeleteController();
        message.id = object.id ?? "";
        message.controllerDid = object.controllerDid ?? "";
        message.signer = object.signer ?? "";
        return message;
    },
};
function createBaseMsgDeleteControllerResponse() {
    return {};
}
export const MsgDeleteControllerResponse = {
    encode(_, writer = _m0.Writer.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgDeleteControllerResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(_) {
        return {};
    },
    toJSON(_) {
        const obj = {};
        return obj;
    },
    create(base) {
        return MsgDeleteControllerResponse.fromPartial(base ?? {});
    },
    fromPartial(_) {
        const message = createBaseMsgDeleteControllerResponse();
        return message;
    },
};
export class MsgClientImpl {
    rpc;
    service;
    constructor(rpc, opts) {
        this.service = opts?.service || "allinbits.cosmoscash.did.Msg";
        this.rpc = rpc;
        this.CreateDidDocument = this.CreateDidDocument.bind(this);
        this.UpdateDidDocument = this.UpdateDidDocument.bind(this);
        this.AddVerification = this.AddVerification.bind(this);
        this.RevokeVerification = this.RevokeVerification.bind(this);
        this.SetVerificationRelationships = this.SetVerificationRelationships.bind(this);
        this.AddService = this.AddService.bind(this);
        this.DeleteService = this.DeleteService.bind(this);
        this.AddController = this.AddController.bind(this);
        this.DeleteController = this.DeleteController.bind(this);
    }
    CreateDidDocument(request) {
        const data = MsgCreateDidDocument.encode(request).finish();
        const promise = this.rpc.request(this.service, "CreateDidDocument", data);
        return promise.then((data) => MsgCreateDidDocumentResponse.decode(_m0.Reader.create(data)));
    }
    UpdateDidDocument(request) {
        const data = MsgUpdateDidDocument.encode(request).finish();
        const promise = this.rpc.request(this.service, "UpdateDidDocument", data);
        return promise.then((data) => MsgUpdateDidDocumentResponse.decode(_m0.Reader.create(data)));
    }
    AddVerification(request) {
        const data = MsgAddVerification.encode(request).finish();
        const promise = this.rpc.request(this.service, "AddVerification", data);
        return promise.then((data) => MsgAddVerificationResponse.decode(_m0.Reader.create(data)));
    }
    RevokeVerification(request) {
        const data = MsgRevokeVerification.encode(request).finish();
        const promise = this.rpc.request(this.service, "RevokeVerification", data);
        return promise.then((data) => MsgRevokeVerificationResponse.decode(_m0.Reader.create(data)));
    }
    SetVerificationRelationships(request) {
        const data = MsgSetVerificationRelationships.encode(request).finish();
        const promise = this.rpc.request(this.service, "SetVerificationRelationships", data);
        return promise.then((data) => MsgSetVerificationRelationshipsResponse.decode(_m0.Reader.create(data)));
    }
    AddService(request) {
        const data = MsgAddService.encode(request).finish();
        const promise = this.rpc.request(this.service, "AddService", data);
        return promise.then((data) => MsgAddServiceResponse.decode(_m0.Reader.create(data)));
    }
    DeleteService(request) {
        const data = MsgDeleteService.encode(request).finish();
        const promise = this.rpc.request(this.service, "DeleteService", data);
        return promise.then((data) => MsgDeleteServiceResponse.decode(_m0.Reader.create(data)));
    }
    AddController(request) {
        const data = MsgAddController.encode(request).finish();
        const promise = this.rpc.request(this.service, "AddController", data);
        return promise.then((data) => MsgAddControllerResponse.decode(_m0.Reader.create(data)));
    }
    DeleteController(request) {
        const data = MsgDeleteController.encode(request).finish();
        const promise = this.rpc.request(this.service, "DeleteController", data);
        return promise.then((data) => MsgDeleteControllerResponse.decode(_m0.Reader.create(data)));
    }
}
if (_m0.util.Long !== Long) {
    _m0.util.Long = Long;
    _m0.configure();
}
function isSet(value) {
    return value !== null && value !== undefined;
}
//# sourceMappingURL=tx.js.map