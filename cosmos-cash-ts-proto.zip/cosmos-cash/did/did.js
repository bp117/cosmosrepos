/* eslint-disable */
import Long from "long";
import _m0 from "protobufjs/minimal";
import { Timestamp } from "../google/protobuf/timestamp";
export const protobufPackage = "allinbits.cosmoscash.did";
function createBaseDidDocument() {
    return {
        context: [],
        id: "",
        controller: [],
        verificationMethod: [],
        service: [],
        authentication: [],
        assertionMethod: [],
        keyAgreement: [],
        capabilityInvocation: [],
        capabilityDelegation: [],
    };
}
export const DidDocument = {
    encode(message, writer = _m0.Writer.create()) {
        for (const v of message.context) {
            writer.uint32(10).string(v);
        }
        if (message.id !== "") {
            writer.uint32(18).string(message.id);
        }
        for (const v of message.controller) {
            writer.uint32(26).string(v);
        }
        for (const v of message.verificationMethod) {
            VerificationMethod.encode(v, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.service) {
            Service.encode(v, writer.uint32(42).fork()).ldelim();
        }
        for (const v of message.authentication) {
            writer.uint32(50).string(v);
        }
        for (const v of message.assertionMethod) {
            writer.uint32(58).string(v);
        }
        for (const v of message.keyAgreement) {
            writer.uint32(66).string(v);
        }
        for (const v of message.capabilityInvocation) {
            writer.uint32(74).string(v);
        }
        for (const v of message.capabilityDelegation) {
            writer.uint32(82).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDidDocument();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.context.push(reader.string());
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.controller.push(reader.string());
                    continue;
                case 4:
                    if (tag != 34) {
                        break;
                    }
                    message.verificationMethod.push(VerificationMethod.decode(reader, reader.uint32()));
                    continue;
                case 5:
                    if (tag != 42) {
                        break;
                    }
                    message.service.push(Service.decode(reader, reader.uint32()));
                    continue;
                case 6:
                    if (tag != 50) {
                        break;
                    }
                    message.authentication.push(reader.string());
                    continue;
                case 7:
                    if (tag != 58) {
                        break;
                    }
                    message.assertionMethod.push(reader.string());
                    continue;
                case 8:
                    if (tag != 66) {
                        break;
                    }
                    message.keyAgreement.push(reader.string());
                    continue;
                case 9:
                    if (tag != 74) {
                        break;
                    }
                    message.capabilityInvocation.push(reader.string());
                    continue;
                case 10:
                    if (tag != 82) {
                        break;
                    }
                    message.capabilityDelegation.push(reader.string());
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            context: Array.isArray(object?.context) ? object.context.map((e) => String(e)) : [],
            id: isSet(object.id) ? String(object.id) : "",
            controller: Array.isArray(object?.controller) ? object.controller.map((e) => String(e)) : [],
            verificationMethod: Array.isArray(object?.verificationMethod)
                ? object.verificationMethod.map((e) => VerificationMethod.fromJSON(e))
                : [],
            service: Array.isArray(object?.service) ? object.service.map((e) => Service.fromJSON(e)) : [],
            authentication: Array.isArray(object?.authentication) ? object.authentication.map((e) => String(e)) : [],
            assertionMethod: Array.isArray(object?.assertionMethod) ? object.assertionMethod.map((e) => String(e)) : [],
            keyAgreement: Array.isArray(object?.keyAgreement) ? object.keyAgreement.map((e) => String(e)) : [],
            capabilityInvocation: Array.isArray(object?.capabilityInvocation)
                ? object.capabilityInvocation.map((e) => String(e))
                : [],
            capabilityDelegation: Array.isArray(object?.capabilityDelegation)
                ? object.capabilityDelegation.map((e) => String(e))
                : [],
        };
    },
    toJSON(message) {
        const obj = {};
        if (message.context) {
            obj.context = message.context.map((e) => e);
        }
        else {
            obj.context = [];
        }
        message.id !== undefined && (obj.id = message.id);
        if (message.controller) {
            obj.controller = message.controller.map((e) => e);
        }
        else {
            obj.controller = [];
        }
        if (message.verificationMethod) {
            obj.verificationMethod = message.verificationMethod.map((e) => e ? VerificationMethod.toJSON(e) : undefined);
        }
        else {
            obj.verificationMethod = [];
        }
        if (message.service) {
            obj.service = message.service.map((e) => e ? Service.toJSON(e) : undefined);
        }
        else {
            obj.service = [];
        }
        if (message.authentication) {
            obj.authentication = message.authentication.map((e) => e);
        }
        else {
            obj.authentication = [];
        }
        if (message.assertionMethod) {
            obj.assertionMethod = message.assertionMethod.map((e) => e);
        }
        else {
            obj.assertionMethod = [];
        }
        if (message.keyAgreement) {
            obj.keyAgreement = message.keyAgreement.map((e) => e);
        }
        else {
            obj.keyAgreement = [];
        }
        if (message.capabilityInvocation) {
            obj.capabilityInvocation = message.capabilityInvocation.map((e) => e);
        }
        else {
            obj.capabilityInvocation = [];
        }
        if (message.capabilityDelegation) {
            obj.capabilityDelegation = message.capabilityDelegation.map((e) => e);
        }
        else {
            obj.capabilityDelegation = [];
        }
        return obj;
    },
    create(base) {
        return DidDocument.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseDidDocument();
        message.context = object.context?.map((e) => e) || [];
        message.id = object.id ?? "";
        message.controller = object.controller?.map((e) => e) || [];
        message.verificationMethod = object.verificationMethod?.map((e) => VerificationMethod.fromPartial(e)) || [];
        message.service = object.service?.map((e) => Service.fromPartial(e)) || [];
        message.authentication = object.authentication?.map((e) => e) || [];
        message.assertionMethod = object.assertionMethod?.map((e) => e) || [];
        message.keyAgreement = object.keyAgreement?.map((e) => e) || [];
        message.capabilityInvocation = object.capabilityInvocation?.map((e) => e) || [];
        message.capabilityDelegation = object.capabilityDelegation?.map((e) => e) || [];
        return message;
    },
};
function createBaseVerificationMethod() {
    return {
        id: "",
        type: "",
        controller: "",
        blockchainAccountID: undefined,
        publicKeyHex: undefined,
        publicKeyMultibase: undefined,
    };
}
export const VerificationMethod = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.type !== "") {
            writer.uint32(18).string(message.type);
        }
        if (message.controller !== "") {
            writer.uint32(26).string(message.controller);
        }
        if (message.blockchainAccountID !== undefined) {
            writer.uint32(34).string(message.blockchainAccountID);
        }
        if (message.publicKeyHex !== undefined) {
            writer.uint32(42).string(message.publicKeyHex);
        }
        if (message.publicKeyMultibase !== undefined) {
            writer.uint32(50).string(message.publicKeyMultibase);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseVerificationMethod();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.type = reader.string();
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.controller = reader.string();
                    continue;
                case 4:
                    if (tag != 34) {
                        break;
                    }
                    message.blockchainAccountID = reader.string();
                    continue;
                case 5:
                    if (tag != 42) {
                        break;
                    }
                    message.publicKeyHex = reader.string();
                    continue;
                case 6:
                    if (tag != 50) {
                        break;
                    }
                    message.publicKeyMultibase = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            id: isSet(object.id) ? String(object.id) : "",
            type: isSet(object.type) ? String(object.type) : "",
            controller: isSet(object.controller) ? String(object.controller) : "",
            blockchainAccountID: isSet(object.blockchainAccountID) ? String(object.blockchainAccountID) : undefined,
            publicKeyHex: isSet(object.publicKeyHex) ? String(object.publicKeyHex) : undefined,
            publicKeyMultibase: isSet(object.publicKeyMultibase) ? String(object.publicKeyMultibase) : undefined,
        };
    },
    toJSON(message) {
        const obj = {};
        message.id !== undefined && (obj.id = message.id);
        message.type !== undefined && (obj.type = message.type);
        message.controller !== undefined && (obj.controller = message.controller);
        message.blockchainAccountID !== undefined && (obj.blockchainAccountID = message.blockchainAccountID);
        message.publicKeyHex !== undefined && (obj.publicKeyHex = message.publicKeyHex);
        message.publicKeyMultibase !== undefined && (obj.publicKeyMultibase = message.publicKeyMultibase);
        return obj;
    },
    create(base) {
        return VerificationMethod.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseVerificationMethod();
        message.id = object.id ?? "";
        message.type = object.type ?? "";
        message.controller = object.controller ?? "";
        message.blockchainAccountID = object.blockchainAccountID ?? undefined;
        message.publicKeyHex = object.publicKeyHex ?? undefined;
        message.publicKeyMultibase = object.publicKeyMultibase ?? undefined;
        return message;
    },
};
function createBaseService() {
    return { id: "", type: "", serviceEndpoint: "" };
}
export const Service = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.type !== "") {
            writer.uint32(18).string(message.type);
        }
        if (message.serviceEndpoint !== "") {
            writer.uint32(26).string(message.serviceEndpoint);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseService();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.type = reader.string();
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.serviceEndpoint = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            id: isSet(object.id) ? String(object.id) : "",
            type: isSet(object.type) ? String(object.type) : "",
            serviceEndpoint: isSet(object.serviceEndpoint) ? String(object.serviceEndpoint) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.id !== undefined && (obj.id = message.id);
        message.type !== undefined && (obj.type = message.type);
        message.serviceEndpoint !== undefined && (obj.serviceEndpoint = message.serviceEndpoint);
        return obj;
    },
    create(base) {
        return Service.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseService();
        message.id = object.id ?? "";
        message.type = object.type ?? "";
        message.serviceEndpoint = object.serviceEndpoint ?? "";
        return message;
    },
};
function createBaseDidMetadata() {
    return { versionId: "", created: undefined, updated: undefined, deactivated: false };
}
export const DidMetadata = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.versionId !== "") {
            writer.uint32(10).string(message.versionId);
        }
        if (message.created !== undefined) {
            Timestamp.encode(toTimestamp(message.created), writer.uint32(18).fork()).ldelim();
        }
        if (message.updated !== undefined) {
            Timestamp.encode(toTimestamp(message.updated), writer.uint32(26).fork()).ldelim();
        }
        if (message.deactivated === true) {
            writer.uint32(32).bool(message.deactivated);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDidMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.versionId = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.created = fromTimestamp(Timestamp.decode(reader, reader.uint32()));
                    continue;
                case 3:
                    if (tag != 26) {
                        break;
                    }
                    message.updated = fromTimestamp(Timestamp.decode(reader, reader.uint32()));
                    continue;
                case 4:
                    if (tag != 32) {
                        break;
                    }
                    message.deactivated = reader.bool();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            versionId: isSet(object.versionId) ? String(object.versionId) : "",
            created: isSet(object.created) ? fromJsonTimestamp(object.created) : undefined,
            updated: isSet(object.updated) ? fromJsonTimestamp(object.updated) : undefined,
            deactivated: isSet(object.deactivated) ? Boolean(object.deactivated) : false,
        };
    },
    toJSON(message) {
        const obj = {};
        message.versionId !== undefined && (obj.versionId = message.versionId);
        message.created !== undefined && (obj.created = message.created.toISOString());
        message.updated !== undefined && (obj.updated = message.updated.toISOString());
        message.deactivated !== undefined && (obj.deactivated = message.deactivated);
        return obj;
    },
    create(base) {
        return DidMetadata.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseDidMetadata();
        message.versionId = object.versionId ?? "";
        message.created = object.created ?? undefined;
        message.updated = object.updated ?? undefined;
        message.deactivated = object.deactivated ?? false;
        return message;
    },
};
function toTimestamp(date) {
    const seconds = numberToLong(date.getTime() / 1_000);
    const nanos = (date.getTime() % 1_000) * 1_000_000;
    return { seconds, nanos };
}
function fromTimestamp(t) {
    let millis = t.seconds.toNumber() * 1_000;
    millis += t.nanos / 1_000_000;
    return new Date(millis);
}
function fromJsonTimestamp(o) {
    if (o instanceof Date) {
        return o;
    }
    else if (typeof o === "string") {
        return new Date(o);
    }
    else {
        return fromTimestamp(Timestamp.fromJSON(o));
    }
}
function numberToLong(number) {
    return Long.fromNumber(number);
}
if (_m0.util.Long !== Long) {
    _m0.util.Long = Long;
    _m0.configure();
}
function isSet(value) {
    return value !== null && value !== undefined;
}
//# sourceMappingURL=did.js.map