export * from './did';
export * from './query';
export * from './tx';
export * from './event';
export const protobufPackage = "allinbits.cosmoscash.did";
//# sourceMappingURL=index.js.map