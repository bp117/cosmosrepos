/* eslint-disable */
import Long from "long";
import _m0 from "protobufjs/minimal";
export const protobufPackage = "allinbits.cosmoscash.did";
function createBaseDidDocumentCreatedEvent() {
    return { did: "", signer: "" };
}
export const DidDocumentCreatedEvent = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.did !== "") {
            writer.uint32(10).string(message.did);
        }
        if (message.signer !== "") {
            writer.uint32(18).string(message.signer);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDidDocumentCreatedEvent();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.did = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.signer = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            did: isSet(object.did) ? String(object.did) : "",
            signer: isSet(object.signer) ? String(object.signer) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.did !== undefined && (obj.did = message.did);
        message.signer !== undefined && (obj.signer = message.signer);
        return obj;
    },
    create(base) {
        return DidDocumentCreatedEvent.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseDidDocumentCreatedEvent();
        message.did = object.did ?? "";
        message.signer = object.signer ?? "";
        return message;
    },
};
function createBaseDidDocumentUpdatedEvent() {
    return { did: "", signer: "" };
}
export const DidDocumentUpdatedEvent = {
    encode(message, writer = _m0.Writer.create()) {
        if (message.did !== "") {
            writer.uint32(10).string(message.did);
        }
        if (message.signer !== "") {
            writer.uint32(18).string(message.signer);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDidDocumentUpdatedEvent();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag != 10) {
                        break;
                    }
                    message.did = reader.string();
                    continue;
                case 2:
                    if (tag != 18) {
                        break;
                    }
                    message.signer = reader.string();
                    continue;
            }
            if ((tag & 7) == 4 || tag == 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON(object) {
        return {
            did: isSet(object.did) ? String(object.did) : "",
            signer: isSet(object.signer) ? String(object.signer) : "",
        };
    },
    toJSON(message) {
        const obj = {};
        message.did !== undefined && (obj.did = message.did);
        message.signer !== undefined && (obj.signer = message.signer);
        return obj;
    },
    create(base) {
        return DidDocumentUpdatedEvent.fromPartial(base ?? {});
    },
    fromPartial(object) {
        const message = createBaseDidDocumentUpdatedEvent();
        message.did = object.did ?? "";
        message.signer = object.signer ?? "";
        return message;
    },
};
if (_m0.util.Long !== Long) {
    _m0.util.Long = Long;
    _m0.configure();
}
function isSet(value) {
    return value !== null && value !== undefined;
}
//# sourceMappingURL=event.js.map